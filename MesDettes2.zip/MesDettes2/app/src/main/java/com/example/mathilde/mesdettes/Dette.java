package com.example.mathilde.mesdettes;

public class Dette {

    private int ID;
    private String username;
    private String debitteur;
    private double amount;
    private boolean archive;

    public Dette(int ID, String user, String deb, double money,boolean arch){
        this.ID=ID;
        this.username=user;
        this.debitteur=deb;
        this.amount=money;
        this.archive=arch;
    }
    public int getID(){
        return ID;
    }
    public void setID(int i){
        ID=i;
    }
    public String getUsername(){
        return username;
    }
    public void setUsername(String i){
        username=i;
    }
    public String getDebitteur(){
        return debitteur;
    }
    public void setDebitteur(String i){
        debitteur=i;
    }
    public double getAmount(){
        return amount;
    }
    public void setAmount(double i){
        amount=i;
    }
    public boolean getArchive(){
        return archive;
    }
    public void setArchive(boolean i){
        archive=i;
    }





}
