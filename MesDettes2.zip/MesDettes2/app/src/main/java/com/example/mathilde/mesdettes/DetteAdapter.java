package com.example.mathilde.mesdettes;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;


public class DetteAdapter extends BaseAdapter {

    private ArrayList<Dette> lstDettes = new ArrayList<Dette>();
    private Context context;
    private LayoutInflater inflater;

    public DetteAdapter(Context context, ArrayList<Dette> listDettes){
        this.context = context;
        lstDettes = listDettes;
        inflater = LayoutInflater.from(context);

    }

    public int getCount(){
        return lstDettes.size();
    }


    public Object getItem(int position) {
        return lstDettes.get(position);
    }

    public long getItemId(int position) {
        return position;
    }




    public View getView(int position, View convertView, ViewGroup parent){
        LinearLayout layoutItem;
        //(1) : Réutilisation des layouts
        if (convertView == null) {
            //Initialisation de notre item à partir du  layout XML "personne_layout.xml"
            layoutItem = (LinearLayout) inflater.inflate(R.layout.todoview, parent, false);
        } else {
            layoutItem = (LinearLayout) convertView;
        }

        //(2) : Récupération des TextView de notre layout
        TextView nom = (TextView)layoutItem.findViewById(R.id.detteNom);
        TextView amount = (TextView)layoutItem.findViewById(R.id.detteAmount);

        //(3) : Renseignement des valeurs
        nom.setText(lstDettes.get(position).getDebitteur());
        amount.setText(""+lstDettes.get(position).getAmount());



        //On retourne l'item créé.
        return layoutItem;
    }



}

