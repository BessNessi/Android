package com.example.mathilde.mesdettes;


import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class ArchiveDetteActivity extends Activity {

    ArrayList<String> items;
    ArrayList<Dette> dettes;
    ArrayAdapter<String> itemsAdapter;
    ListView lvItems;
    LoginDataBaseAdapter loginDataBaseAdapter;

    Button btnAdd;

    private String username = null;


    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.todolist);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            username =extras.getString("username");
        }

        loginDataBaseAdapter=new LoginDataBaseAdapter(this);
        loginDataBaseAdapter=loginDataBaseAdapter.open();

        // ADD HERE
        lvItems = (ListView) findViewById(R.id.lvItems);
        items = new ArrayList<String>();
        dettes = new ArrayList<Dette>();
        ArrayList<Integer> Ids=new ArrayList<Integer>();


        dettes = loginDataBaseAdapter.getDetteByUserArch(username);

        for(int i=0;i<dettes.size();i++){
            items.add(dettes.get(i).getDebitteur() + " me doit " + dettes.get(i).getAmount() + " dollars");
        }
        for(int i=0;i<dettes.size();i++){
            Ids.add(dettes.get(i).getID());
        }


        itemsAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, items);

        lvItems.setAdapter(itemsAdapter);

        lvItems.setOnItemLongClickListener(

                new AdapterView.OnItemLongClickListener() {
                    @Override
                    public boolean onItemLongClick(AdapterView<?> adapter,
                                                   View item, final int pos, long id) {
                        final Dialog dialog = new Dialog(ArchiveDetteActivity.this);
                        dialog.setContentView(R.layout.supprarch);
                        dialog.setTitle("Supprimer/Archiver");
                        Button suppr=(Button)dialog.findViewById(R.id.btnSuppr);
                        Button arch=(Button)dialog.findViewById(R.id.btnArch);

                        suppr.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {
                                items.remove(pos);
                                loginDataBaseAdapter.deleteEntryDette(loginDataBaseAdapter.getDetteByUserNoArch(username).get(pos).getID());
                                itemsAdapter.notifyDataSetChanged();
                                dialog.dismiss();
                            }

                        });

                        arch.setOnClickListener(new View.OnClickListener() {
                            public void onClick(View v) {
                                loginDataBaseAdapter.serArchiveEntryDette(loginDataBaseAdapter.getDetteByUserNoArch(username).get(pos).getID());
                                items.remove(pos);
                                itemsAdapter.notifyDataSetChanged();
                                dialog.dismiss();
                            }

                        });

                        dialog.show();


                        return true;
                    }

                });
        btnAdd=(Button)findViewById(R.id.btnAddItem);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        // Inflate the menu:
        getMenuInflater().inflate(R.menu.menu_todo, menu);
        this.findViewById(R.id.ic_menumenu);

        return true;
    }

    /* Handle the menu selection */
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.ic_menumenu:
                showFavourites();
                return true;
        }
        return false;
    }
    public void showFavourites(){
        Intent intentToDoActivity=new Intent(getApplicationContext(),ToDoActivity.class);
        intentToDoActivity.putExtra("username", username);
        this.finish();
        startActivity(intentToDoActivity);
    }


    public void onAddItem(View V)
    {
        final Dialog dialog = new Dialog(ArchiveDetteActivity.this);
        dialog.setContentView(R.layout.adddette);
        dialog.setTitle("Ajouter une dette");

        // get the Refferences of views
        final  EditText editTextDebitor=(EditText)dialog.findViewById(R.id.detteNewdebitor);
        final  EditText editTextAmount=(EditText)dialog.findViewById(R.id.detteNewAmount);

        Button addDette=(Button)dialog.findViewById(R.id.buttonAddDette);
        // Set On ClickListener
        addDette.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                String debitor= editTextDebitor.getText().toString();
                if (debitor.equals("")) {
                    Toast.makeText(ArchiveDetteActivity.this, "Bah qui vous doit des sousous !?", Toast.LENGTH_LONG).show();
                } else {
                    if (editTextAmount.getText().toString().equals("")) {
                        Toast.makeText(ArchiveDetteActivity.this, "Il manque les sousous $$$", Toast.LENGTH_LONG).show();
                    }else{

                        try {
                            Double amount = Double.parseDouble(editTextAmount.getText().toString());

                            try {
                                loginDataBaseAdapter.insertEntryDette(username, debitor, amount);
                                dialog.dismiss();
                                itemsAdapter.add(debitor + " me doit " + amount + " dollars");

                            } catch (Exception e) {
                                Toast.makeText(ArchiveDetteActivity.this, "Vous avez mal fait quelque chose", Toast.LENGTH_LONG).show();
                            }
                        }
                        catch (Exception e){
                            Toast.makeText(ArchiveDetteActivity.this, "Vous avez mal fait quelque chose", Toast.LENGTH_LONG).show();
                        }
                    }
                }

            }

        });

        dialog.show();
    }

}