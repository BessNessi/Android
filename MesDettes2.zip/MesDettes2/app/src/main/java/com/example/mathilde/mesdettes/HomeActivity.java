package com.example.mathilde.mesdettes;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class HomeActivity extends Activity
{
    Button btnSignIn,btnSignUp;
    LoginDataBaseAdapter loginDataBaseAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);


        // create a instance of SQLite Database
        loginDataBaseAdapter=new LoginDataBaseAdapter(this);
        loginDataBaseAdapter=loginDataBaseAdapter.open();

        // Get The Refference Of Buttons
        btnSignIn=(Button)findViewById(R.id.buttonSignIN);
        btnSignUp=(Button)findViewById(R.id.buttonSignUp);

    }
    // Methos to handleClick Event of Sign In Button
    public void signIn(View V)
    {
        final Dialog dialog = new Dialog(HomeActivity.this);
        dialog.setContentView(R.layout.login);
        dialog.setTitle("Login");

        // get the Refferences of views
        final  EditText editTextUserName=(EditText)dialog.findViewById(R.id.editTextUserNameToLogin);
        final  EditText editTextPassword=(EditText)dialog.findViewById(R.id.editTextPasswordToLogin);

        Button btnSignIn=(Button)dialog.findViewById(R.id.buttonSignIn);

        // Set On ClickListener
        btnSignIn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                // get The User name and Password
                String userName=editTextUserName.getText().toString();
                String password=editTextPassword.getText().toString();

                // fetch the Password form database for respective user name
                String storedPassword=loginDataBaseAdapter.getSingleEntry(userName);

                // check if the Stored password matches with  Password entered by user
                if(password.equals(storedPassword))
                {
                    Toast.makeText(HomeActivity.this, "Congrats: Login Successfull", Toast.LENGTH_LONG).show();
                    dialog.dismiss();
                    Intent intentToDoActivity=new Intent(getApplicationContext(),ToDoActivity.class);
                    intentToDoActivity.putExtra("username",userName);
                    startActivity(intentToDoActivity);
                }
                else
                {
                    Toast.makeText(HomeActivity.this, "User Name or Password does not match", Toast.LENGTH_LONG).show();
                }
            }
        });

        dialog.show();
    }

    public void signUp(View V)
    {
        final Dialog dialog = new Dialog(HomeActivity.this);
        dialog.setContentView(R.layout.signup);
        dialog.setTitle("register");


        // get the Refferences of views
        final  EditText editTextUserNamer=(EditText)dialog.findViewById(R.id.UserNameregister);
        final  EditText editTextPasswordr=(EditText)dialog.findViewById(R.id.PasswordToRegister);
        final  EditText editTextPasswordconf=(EditText)dialog.findViewById(R.id.ConfirmPasswordToRegister);

        Button btnSignUp=(Button)dialog.findViewById(R.id.buttonSignUp);

        // Set On ClickListener
        btnSignUp.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                // get The User name and Password
                String userName=editTextUserNamer.getText().toString();
                String password=editTextPasswordr.getText().toString();
                String passwordConf=editTextPasswordconf.getText().toString();

                // check if the Stored password matches with  Password entered by user

                if(userName.equals("")||password.equals("")||passwordConf.equals(""))
                {
                    Toast.makeText(getApplicationContext(), "Field Vaccant", Toast.LENGTH_LONG).show();
                    return;
                }
                if(password.equals(passwordConf))
                {
                    if(loginDataBaseAdapter.getSingleEntry(userName)=="NOT EXIST") {
                        // Save the Data in Database
                        loginDataBaseAdapter.insertEntry(userName, password);
                        Toast.makeText(getApplicationContext(), "Account Successfully Created ", Toast.LENGTH_LONG).show();


                        dialog.dismiss();
                        Intent intentToDoActivity=new Intent(getApplicationContext(),ToDoActivity.class);
                        intentToDoActivity.putExtra("username", userName);
                        startActivity(intentToDoActivity);
                    }
                    else{
                        Toast.makeText(getApplicationContext(), "Account exist already ", Toast.LENGTH_LONG).show();
                    }
                }
                else
                {
                    Toast.makeText(HomeActivity.this, "Password does not match", Toast.LENGTH_LONG).show();
                }
            }
        });

        dialog.show();
    }



    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Close The Database
        loginDataBaseAdapter.close();
    }
}
